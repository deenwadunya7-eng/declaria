export default function PrivacidadPage() {
  return (
    <main className="max-w-3xl mx-auto px-6 py-20 text-gray-800">
      <h1 className="text-3xl font-bold mb-8">Política de Privacidad</h1>
      <p className="mb-4">En <strong>DeclarIA</strong> nos tomamos en serio tu privacidad. Tratamos tus datos de acuerdo con el Reglamento General de Protección de Datos (RGPD).</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">1. Responsable</h2>
      <p className="mb-4">DeclarIA (fase inicial). Contacto: <a href="mailto:soporte@declaria.app" className="underline">soporte@declaria.app</a>.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">2. Datos que recopilamos</h2>
      <ul className="list-disc ml-6 mb-4">
        <li>Datos de registro: nombre, email y organización.</li>
        <li>Datos de facturación y suscripción procesados por Stripe.</li>
        <li>Documentos y facturas que subas voluntariamente.</li>
        <li>Consultas realizadas al asistente de IA.</li>
      </ul>
      <h2 className="text-xl font-semibold mt-6 mb-2">3. Finalidad</h2>
      <p className="mb-4">Prestar el servicio, facturación, soporte y mejora de la plataforma.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">4. Base legal</h2>
      <p className="mb-4">Ejecución del contrato de suscripción y consentimiento expreso para funcionalidades concretas.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">5. Conservación</h2>
      <p className="mb-4">Mientras seas cliente y posteriormente por plazos legales. Puedes solicitar la eliminación.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">6. Derechos</h2>
      <p className="mb-4">Acceso, rectificación, supresión, limitación y portabilidad: <a href="mailto:soporte@declaria.app" className="underline">soporte@declaria.app</a>.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">7. Terceros</h2>
      <p className="mb-4">Proveedores: Stripe, Supabase, Vercel, OpenAI. Actúan como encargados y cumplen RGPD.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">8. Seguridad</h2>
      <p className="mb-4">Cifrado y servidores europeos. Medidas técnicas y organizativas razonables.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">9. Cambios</h2>
      <p className="mb-4">Notificaremos cambios sustanciales en esta política.</p>
    </main>
  );
}
