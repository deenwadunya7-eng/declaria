'use client';
import { useState } from 'react';

export default function CheckoutPage(){
  const [loading, setLoading] = useState<string | null>(null);

  async function createSession(priceKey:string){
    setLoading(priceKey);
    const res = await fetch('/api/stripe/checkout', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ priceKey })
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
    else alert(data.error || 'No se pudo iniciar el checkout.');
    setLoading(null);
  }

  return (
    <main className="max-w-3xl mx-auto px-6 py-20">
      <h1 className="text-3xl font-bold">Elige tu plan</h1>
      <p className="text-gray-600 mt-2">Pago seguro con Stripe. Sin permanencia.</p>
      <div className="grid md:grid-cols-3 gap-6 mt-10">
        <button onClick={()=>createSession('BASIC')} className="p-6 border rounded-2xl hover:bg-gray-50">
          <p className="font-semibold">Básico</p>
          <p className="text-3xl font-bold mt-2">29€<span className="text-base">/mes</span></p>
          <p className="text-sm text-gray-600 mt-2">IA + contratos</p>
          <span className="inline-block mt-4 px-4 py-2 rounded-xl bg-blue-600 text-white">{loading==='BASIC'?'Creando...':'Elegir plan'}</span>
        </button>
        <button onClick={()=>createSession('PRO')} className="p-6 border-2 border-blue-600 rounded-2xl bg-blue-50 hover:bg-blue-100">
          <p className="font-semibold">Pro</p>
          <p className="text-3xl font-bold mt-2">59€<span className="text-base">/mes</span></p>
          <p className="text-sm text-gray-600 mt-2">+ Modelos fiscales</p>
          <span className="inline-block mt-4 px-4 py-2 rounded-xl bg-blue-600 text-white">{loading==='PRO'?'Creando...':'Elegir plan'}</span>
        </button>
        <button onClick={()=>createSession('PREMIUM')} className="p-6 border rounded-2xl hover:bg-gray-50">
          <p className="font-semibold">Premium</p>
          <p className="text-3xl font-bold mt-2">99€<span className="text-base">/mes</span></p>
          <p className="text-sm text-gray-600 mt-2">+ Soporte humano</p>
          <span className="inline-block mt-4 px-4 py-2 rounded-xl bg-blue-600 text-white">{loading==='PREMIUM'?'Creando...':'Elegir plan'}</span>
        </button>
      </div>
    </main>
  );
}
