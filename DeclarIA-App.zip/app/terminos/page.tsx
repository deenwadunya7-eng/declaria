export default function TerminosPage() {
  return (
    <main className="max-w-3xl mx-auto px-6 py-20 text-gray-800">
      <h1 className="text-3xl font-bold mb-8">Términos y Condiciones de Uso</h1>
      <p className="mb-4">Bienvenido a <strong>DeclarIA</strong>. Al utilizar nuestra plataforma aceptas los siguientes términos:</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">1. Objeto del servicio</h2>
      <p className="mb-4">DeclarIA ofrece una herramienta de asistencia fiscal y legal mediante inteligencia artificial. No somos una gestoría ni un despacho de abogados: el servicio es de apoyo y automatización, pero no sustituye asesoramiento profesional personalizado.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">2. Registro y cuenta</h2>
      <p className="mb-4">Para utilizar DeclarIA debes registrarte con datos veraces. Eres responsable de mantener la confidencialidad de tus credenciales.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">3. Suscripciones y pagos</h2>
      <p className="mb-4">DeclarIA funciona con suscripciones de pago mensual gestionadas por Stripe. El cobro se realiza por adelantado y se renueva automáticamente. Puedes cancelar en cualquier momento desde tu panel. No se realizan devoluciones por periodos ya facturados.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">4. Limitación de responsabilidad</h2>
      <p className="mb-4">Aunque la plataforma utiliza IA entrenada con normativa española, DeclarIA no garantiza la ausencia de errores. Eres responsable de revisar antes de presentar cualquier documento a la Agencia Tributaria o firmar contratos legales.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">5. Uso aceptable</h2>
      <p className="mb-4">No puedes usar DeclarIA para actividades ilícitas, fraudulentas o contrarias a la normativa vigente.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">6. Modificaciones</h2>
      <p className="mb-4">Podemos actualizar estos términos cuando sea necesario. Te avisaremos en caso de cambios relevantes.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">7. Legislación aplicable</h2>
      <p className="mb-4">Estos términos se rigen por la legislación española. Cualquier disputa será sometida a los juzgados de Madrid.</p>
    </main>
  );
}
