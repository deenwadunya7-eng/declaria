import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  if(!process.env.STRIPE_SECRET_KEY || !process.env.STRIPE_WEBHOOK_SECRET){
    return new NextResponse('Config incompleta', { status: 400 });
  }
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' });
  const sig = req.headers.get('stripe-signature')!;
  const text = await req.text();
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(text, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (e:any) {
    return new NextResponse(`Webhook Error: ${e.message}`, { status: 400 });
  }

  // TODO: guardar estado de suscripción en DB (Supabase). MVP: responder OK.
  return NextResponse.json({ received: true, type: event.type });
}
