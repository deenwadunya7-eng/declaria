import { NextRequest, NextResponse } from 'next/server';
import Tesseract from 'tesseract.js';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get('file') as File | null;
    if(!file) return NextResponse.json({ error: 'No file' }, { status: 400 });
    const buf = Buffer.from(await file.arrayBuffer());
    const { data } = await Tesseract.recognize(buf, 'spa');
    const text = data.text || '';

    function num(m:RegExp){ const v=(text.match(m)||[])[1]; return v?parseFloat(v.replace(/\./g,'').replace(',','.')):null; }
    const number = (text.match(/Nº?\s*Factura[:\s]*([A-Z0-9\-\/]+)/i)||[])[1]||null;
    const net = num(/Base\s*Imponible[:\s]*([0-9\.,]+)/i) || 0;
    const vat = num(/IVA[:\s]*([0-9\.,]+)/i) || 0;
    const rate = net ? Math.round((vat/net)*100) : null;
    return NextResponse.json({ number, net_amount: +net.toFixed(2), vat_amount: +vat.toFixed(2), vat_rate: rate, raw: text.slice(0,1200) });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || 'Error OCR' }, { status: 500 });
  }
}
