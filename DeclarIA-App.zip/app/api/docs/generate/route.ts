import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    if(!process.env.OPENAI_API_KEY) return NextResponse.json({ error: 'Falta OPENAI_API_KEY' }, { status: 400 });
    const { datos } = await req.json();
    const prompt = `Redacta contrato de prestación de servicios en España, lenguaje claro,
cláusulas: objeto, alcance, precio/facturación, PI, confidencialidad, RGPD, responsabilidad,
duración/rescisión, jurisdicción (${datos?.jurisdiccion || 'Madrid'}).
Proveedor ${datos?.proveedor||'Proveedor'}, cliente ${datos?.cliente||'Cliente'}, precio ${datos?.precio||'—'}, objeto ${datos?.objeto||'—'}.`;
    const ai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const out = await ai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.1,
    });
    return NextResponse.json({ doc: out.choices[0].message.content });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || 'Error generación' }, { status: 500 });
  }
}
