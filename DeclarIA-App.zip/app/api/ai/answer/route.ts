import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { SYSTEM_PROMPT } from '@/lib/prompts';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    if(!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'Falta OPENAI_API_KEY' }, { status: 400 });
    }
    const { messages } = await req.json();
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...(messages||[])],
      temperature: 0.2,
    });
    return NextResponse.json({ reply: completion.choices[0].message.content });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || 'Error IA' }, { status: 500 });
  }
}
