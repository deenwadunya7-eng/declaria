import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
export const runtime = 'nodejs';

const PRICE_MAP: Record<string, string | undefined> = {
  BASIC: process.env.PRICE_BASIC_ID,
  PRO: process.env.PRICE_PRO_ID,
  PREMIUM: process.env.PRICE_PREMIUM_ID,
};

export async function POST(req: NextRequest){
  try {
    const { priceKey } = await req.json();
    const price = PRICE_MAP[priceKey];
    if(!process.env.STRIPE_SECRET_KEY) return NextResponse.json({ error: 'Falta STRIPE_SECRET_KEY' }, { status: 400 });
    if(!price) return NextResponse.json({ error: 'Precio no configurado' }, { status: 400 });
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' });
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price, quantity: 1 }],
      success_url: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/?success=1`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/checkout`,
    });
    return NextResponse.json({ url: session.url });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || 'Error desconocido' }, { status: 500 });
  }
}
