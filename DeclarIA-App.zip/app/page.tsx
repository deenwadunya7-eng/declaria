import Link from 'next/link';

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-gray-50 text-gray-800">
      {/* Hero */}
      <section className="px-6 py-20 text-center max-w-4xl mx-auto">
        <h1 className="text-5xl font-extrabold tracking-tight text-gray-900">
          Declara sin miedo a <span className="text-blue-600">Hacienda</span>
        </h1>
        <p className="mt-6 text-lg text-gray-600">
          DeclarIA es tu <strong>copiloto fiscal y legal con IA</strong> para autónomos y pymes en España:
          resuelve dudas, genera contratos y prepara borradores de modelos 303 y 130 en minutos.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link
            href="/checkout"
            className="px-8 py-4 bg-blue-600 text-white rounded-2xl shadow-md hover:bg-blue-700 font-semibold"
          >
            Empieza ahora — 29€/mes
          </Link>
          <a
            href="#features"
            className="px-8 py-4 border border-gray-300 rounded-2xl hover:bg-gray-100 font-semibold"
          >
            Ver cómo funciona
          </a>
        </div>
        <p className="mt-4 text-sm text-gray-500">Sin permanencia. Cancela cuando quieras.</p>
      </section>

      {/* Logos confianza */}
      <section className="px-6 py-10 bg-gray-50 border-t border-b">
        <div className="max-w-5xl mx-auto text-center">
          <p className="text-sm uppercase font-semibold text-gray-500">Infraestructura de confianza</p>
          <div className="mt-6 flex justify-center flex-wrap gap-10 opacity-70">
            <img src="/logos/stripe.svg" alt="Stripe" className="h-8" />
            <img src="/logos/vercel.svg" alt="Vercel" className="h-8" />
            <img src="/logos/supabase.svg" alt="Supabase" className="h-8" />
            <img src="/logos/openai.svg" alt="OpenAI" className="h-8" />
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="px-6 py-20 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center">Ahorra horas y evita errores</h2>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          <div className="bg-white shadow-sm rounded-2xl p-6">
            <h3 className="text-xl font-semibold">Asistente fiscal con IA</h3>
            <p className="mt-3 text-gray-600">Pregunta sobre IVA, IRPF, recargo de equivalencia o intracomunitarias. Respuestas claras con referencias.</p>
          </div>
          <div className="bg-white shadow-sm rounded-2xl p-6">
            <h3 className="text-xl font-semibold">Contratos en segundos</h3>
            <p className="mt-3 text-gray-600">Contrato de servicios, NDA y laborales adaptados a España. Descarga y firma.</p>
          </div>
          <div className="bg-white shadow-sm rounded-2xl p-6">
            <h3 className="text-xl font-semibold">Modelos 303/130</h3>
            <p className="mt-3 text-gray-600">Sube facturas, la IA las clasifica y te entrega un borrador de impuestos listo para exportar.</p>
          </div>
        </div>
      </section>

      {/* Testimonio */}
      <section className="px-6 py-20 bg-blue-600 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-lg italic">
            “Con DeclarIA pasé de pelearme con el 303 a tenerlo listo en minutos. Ya no vivo con miedo a los plazos.”
          </p>
          <p className="mt-4 font-semibold">— Laura Gómez, diseñadora freelance</p>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="px-6 py-20 max-w-5xl mx-auto text-center">
        <h2 className="text-3xl font-bold">Planes simples, sin sorpresas</h2>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          <div className="bg-white shadow rounded-2xl p-8 flex flex-col">
            <h3 className="text-xl font-semibold">Básico</h3>
            <p className="mt-2 text-gray-600">IA fiscal + contratos ilimitados</p>
            <p className="mt-6 text-4xl font-bold">29€<span className="text-lg">/mes</span></p>
            <Link href="/checkout" className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700">
              Empieza ahora
            </Link>
          </div>
          <div className="bg-blue-50 border-2 border-blue-600 rounded-2xl p-8 flex flex-col">
            <h3 className="text-xl font-semibold">Pro</h3>
            <p className="mt-2 text-gray-600">Todo lo anterior + modelos fiscales</p>
            <p className="mt-6 text-4xl font-bold">59€<span className="text-lg">/mes</span></p>
            <Link href="/checkout" className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700">
              Probar ahora
            </Link>
          </div>
          <div className="bg-white shadow rounded-2xl p-8 flex flex-col">
            <h3 className="text-xl font-semibold">Premium</h3>
            <p className="mt-2 text-gray-600">Asesor humano bajo demanda</p>
            <p className="mt-6 text-4xl font-bold">99€<span className="text-lg">/mes</span></p>
            <Link href="/checkout" className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700">
              Quiero tranquilidad
            </Link>
          </div>
        </div>
      </section>

      {/* CTA final */}
      <section className="px-6 py-20 bg-gray-900 text-white text-center">
        <h2 className="text-3xl font-bold">Tu negocio, sin miedo a Hacienda</h2>
        <p className="mt-4 text-gray-300">Únete hoy y prepara tus impuestos en minutos.</p>
        <Link
          href="/checkout"
          className="mt-8 inline-block bg-blue-600 px-10 py-4 rounded-2xl font-semibold hover:bg-blue-700"
        >
          Empieza ahora — 29€/mes
        </Link>
      </section>

      {/* Footer */}
      <footer className="px-6 py-10 bg-gray-100 text-sm text-gray-500">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} DeclarIA. No constituye asesoría fiscal o legal.</p>
          <div className="flex items-center gap-4">
            <Link href="/terminos" className="underline hover:text-gray-700">Términos</Link>
            <Link href="/privacidad" className="underline hover:text-gray-700">Privacidad</Link>
            <Link href="/ajustes-privacidad" className="underline hover:text-gray-700">Preferencias de privacidad</Link>
          </div>
        </div>
      </footer>
    </main>
  );
}
