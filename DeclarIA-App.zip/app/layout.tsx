import './globals.css';
import type { Metadata } from 'next';
import CookieBanner from '@/components/CookieBanner';

export const metadata: Metadata = {
  title: 'DeclarIA — Copiloto fiscal y legal con IA',
  description: 'Resuelve dudas, genera contratos y prepara tus impuestos en España en minutos.',
  openGraph: {
    title: 'DeclarIA — Copiloto fiscal y legal con IA',
    description: 'Olvídate del papeleo. Con IA fiscal para autónomos y pymes.',
    url: 'https://declaria.app',
    siteName: 'DeclarIA',
    images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'DeclarIA OG' }],
    locale: 'es_ES',
    type: 'website'
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DeclarIA — Copiloto fiscal y legal con IA',
    description: 'Resuelve dudas, genera contratos y prepara tus impuestos en España en minutos.',
    images: ['/og-image.png']
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body className="min-h-screen bg-white text-gray-800">
        {children}
        <CookieBanner />
        {/* GA condicional (desactivado por defecto, activar con consentimiento y tu ID) */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
(function(){
  function loadGA(){
    try {
      var c = localStorage.getItem('declaria.consent.v1');
      if (!c) return;
      c = JSON.parse(c);
      if (c.analytics) {
        var s1=document.createElement('script'); s1.async=true; s1.src='https://www.googletagmanager.com/gtag/js?id=G-XXXXXXX';
        document.head.appendChild(s1);
        var s2=document.createElement('script');
        s2.innerHTML = "window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config','G-XXXXXXX',{anonymize_ip:true});";
        document.head.appendChild(s2);
      }
    } catch(e){}
  }
  loadGA();
  document.addEventListener('consent.updated', loadGA);
})();`
          }}
        />
      </body>
    </html>
  );
}
