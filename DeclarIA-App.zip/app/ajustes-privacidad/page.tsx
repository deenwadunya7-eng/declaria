'use client';
import { useEffect, useState } from 'react';
import { getConsent, setConsent, ConsentState } from '@/lib/consent';

export default function PrivacySettingsPage() {
  const [consent, setLocal] = useState<ConsentState>({ necessary: true, analytics: false, marketing: false });

  useEffect(() => {
    const c = getConsent();
    if (c) setLocal(c);
  }, []);

  const save = () => {
    setConsent(consent);
    document.dispatchEvent(new CustomEvent('consent.updated', { detail: consent }));
    alert('Preferencias guardadas.');
  };

  return (
    <main className="max-w-3xl mx-auto px-6 py-20 text-gray-800">
      <h1 className="text-3xl font-bold mb-6">Preferencias de privacidad</h1>
      <p className="text-gray-600 mb-6">Controla el uso de cookies y tecnologías similares. Las necesarias siempre están activas.</p>

      <div className="space-y-6">
        <div className="p-4 border rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Necesarias</p>
              <p className="text-sm text-gray-600">Imprescindibles para el funcionamiento básico.</p>
            </div>
            <span className="text-xs px-2 py-1 rounded-full bg-gray-100 border">Siempre activas</span>
          </div>
        </div>

        <div className="p-4 border rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Analítica</p>
              <p className="text-sm text-gray-600">Medición de uso para mejorar la app.</p>
            </div>
            <input type="checkbox" checked={consent.analytics} onChange={(e)=>setLocal({...consent, analytics:e.target.checked})} className="w-5 h-5"/>
          </div>
        </div>

        <div className="p-4 border rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Marketing</p>
              <p className="text-sm text-gray-600">Personalización publicitaria y remarketing.</p>
            </div>
            <input type="checkbox" checked={consent.marketing} onChange={(e)=>setLocal({...consent, marketing:e.target.checked})} className="w-5 h-5"/>
          </div>
        </div>
      </div>

      <div className="mt-8 flex gap-3">
        <button onClick={save} className="px-5 py-3 rounded-xl bg-blue-600 text-white">Guardar</button>
        <button onClick={()=>{ const c:ConsentState={necessary:true,analytics:false,marketing:false}; setLocal(c); setConsent(c); document.dispatchEvent(new CustomEvent('consent.updated',{detail:c})); }} className="px-5 py-3 rounded-xl border">Rechazar todo</button>
        <button onClick={()=>{ const c:ConsentState={necessary:true,analytics:true,marketing:true}; setLocal(c); setConsent(c); document.dispatchEvent(new CustomEvent('consent.updated',{detail:c})); }} className="px-5 py-3 rounded-xl border">Aceptar todo</button>
      </div>
    </main>
  );
}
