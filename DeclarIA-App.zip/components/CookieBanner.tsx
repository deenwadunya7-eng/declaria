'use client';
import { useEffect, useState } from 'react';
import { getConsent, setConsent, ConsentState } from '@/lib/consent';

export default function CookieBanner() {
  const [open, setOpen] = useState(false);
  const [prefsOpen, setPrefsOpen] = useState(false);
  const [analytics, setAnalytics] = useState(false);
  const [marketing, setMarketing] = useState(false);

  useEffect(() => {
    const c = getConsent();
    if (!c) setOpen(true);
  }, []);

  const acceptAll = () => {
    const c: ConsentState = { necessary: true, analytics: true, marketing: true };
    setConsent(c); setOpen(false); setPrefsOpen(false);
    document.dispatchEvent(new CustomEvent('consent.updated', { detail: c }));
  };
  const rejectAll = () => {
    const c: ConsentState = { necessary: true, analytics: false, marketing: false };
    setConsent(c); setOpen(false); setPrefsOpen(false);
    document.dispatchEvent(new CustomEvent('consent.updated', { detail: c }));
  };
  const savePrefs = () => {
    const c: ConsentState = { necessary: true, analytics, marketing };
    setConsent(c); setOpen(false); setPrefsOpen(false);
    document.dispatchEvent(new CustomEvent('consent.updated', { detail: c }));
  };

  if (!open && !prefsOpen) return null;

  return (<>
    {open && (
      <div className="fixed inset-x-0 bottom-0 z-50">
        <div className="mx-auto max-w-5xl m-4 p-4 rounded-2xl shadow-lg bg-white border">
          <div className="md:flex md:items-center md:justify-between gap-4">
            <div className="text-sm text-gray-700">
              Usamos cookies necesarias y, con tu permiso, analítica/marketing. Puedes cambiar tus preferencias.
              Lee nuestra <a href="/privacidad" className="underline">Política de Privacidad</a>.
            </div>
            <div className="flex gap-2 mt-4 md:mt-0">
              <button onClick={()=>setPrefsOpen(true)} className="px-4 py-2 rounded-xl border">Personalizar</button>
              <button onClick={rejectAll} className="px-4 py-2 rounded-xl border">Rechazar</button>
              <button onClick={acceptAll} className="px-4 py-2 rounded-xl bg-blue-600 text-white">Aceptar todo</button>
            </div>
          </div>
        </div>
      </div>
    )}

    {prefsOpen && (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
        <div className="bg-white w-full max-w-lg rounded-2xl p-6 shadow-xl">
          <h3 className="text-xl font-semibold">Preferencias de privacidad</h3>
          <p className="text-sm text-gray-600 mt-2">Las necesarias siempre están activas.</p>

          <div className="mt-6 space-y-4">
            <div className="p-4 border rounded-xl flex items-center justify-between">
              <div><p className="font-medium">Necesarias</p><p className="text-sm text-gray-600">Esenciales.</p></div>
              <span className="text-xs px-2 py-1 rounded-full bg-gray-100 border">Siempre activas</span>
            </div>
            <div className="p-4 border rounded-xl flex items-center justify-between">
              <div><p className="font-medium">Analítica</p><p className="text-sm text-gray-600">Mejora del producto.</p></div>
              <label className="inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" checked={analytics} onChange={(e)=>setAnalytics(e.target.checked)}/>
                <div className="w-11 h-6 bg-gray-200 rounded-full peer-checked:bg-blue-600 relative after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:w-5 after:h-5 after:bg-white after:rounded-full after:transition-all peer-checked:after:translate-x-5"></div>
              </label>
            </div>
            <div className="p-4 border rounded-xl flex items-center justify-between">
              <div><p className="font-medium">Marketing</p><p className="text-sm text-gray-600">Personalización publicitaria.</p></div>
              <label className="inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" checked={marketing} onChange={(e)=>setMarketing(e.target.checked)}/>
                <div className="w-11 h-6 bg-gray-200 rounded-full peer-checked:bg-blue-600 relative after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:w-5 after:h-5 after:bg-white after:rounded-full after:transition-all peer-checked:after:translate-x-5"></div>
              </label>
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-2">
            <button onClick={()=>{setPrefsOpen(false); setOpen(true);}} className="px-4 py-2 rounded-xl border">Volver</button>
            <button onClick={rejectAll} className="px-4 py-2 rounded-xl border">Rechazar todo</button>
            <button onClick={savePrefs} className="px-4 py-2 rounded-xl bg-blue-600 text-white">Guardar preferencias</button>
          </div>
        </div>
      </div>
    )}
  </>);
}
