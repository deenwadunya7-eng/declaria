export function computeVATDraft(invoices: any[]) {
  const emitidas = invoices.filter(i=>i.type==='emitida');
  const recibidas = invoices.filter(i=>i.type==='recibida');
  const ivaRepercutido = emitidas.reduce((a,b)=>a+(b.vat_amount||0),0);
  const ivaSoportado  = recibidas.reduce((a,b)=>a+(b.vat_amount||0),0);
  return { ivaRepercutido, ivaSoportado, resultado: +(ivaRepercutido - ivaSoportado).toFixed(2) };
}
