'use client';
export type ConsentState = { necessary: true; analytics: boolean; marketing: boolean; };
const KEY = 'declaria.consent.v1';
export function getConsent(): ConsentState | null {
  if (typeof window === 'undefined') return null;
  try { const raw = window.localStorage.getItem(KEY); return raw ? JSON.parse(raw) as ConsentState : null; } catch { return null; }
}
export function setConsent(c: ConsentState){
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(KEY, JSON.stringify(c));
  document.cookie = `consent_analytics=${c.analytics ? '1':'0'}; path=/; max-age=31536000; SameSite=Lax`;
  document.cookie = `consent_marketing=${c.marketing ? '1':'0'}; path=/; max-age=31536000; SameSite=Lax`;
}
